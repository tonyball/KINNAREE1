<footer class="page-footer grey lighten-3">
  <div class="container">
    <div class="row">
      <div class="col l6 s12">
      <ul>
        <li><a href="#"><h6 class="black-text">เกี่ยวกับเรา</h6></a></li>
        <li><a href="#"><h6 class="black-text">ข้อตกลงและเงื่อนไข</h6></a></li>
        <li><a href="#"><h6 class="black-text">นโยบายความเป็นส่วนตัว</h6></a></li>
      </ul>
        
      </div>
      <div class="col l4 offset-l2 s12">
        <h5 class="black-text">ติดต่อเรา</h5>
        <ul>
          <li class="footer-img"><a href="#" ><img src="images/Facebook-50.png" width="32" height="32"></a></li>
          <li class="footer-img"><a href="#"  ><img src="images/Instagram-50.png" width="32" height="32"></a></li>
          <li class="footer-img"><a href="#"  ><img src="images/Twitter-50.png" width="32" height="32"></a></li>
          <li class="footer-img"><a href="#"  ><img src="images/YouTube-50.png" width="32" height="32"></a></li>
          <li class="footer-img"><a href="#"  ><img src="images/Tel.png" width="32" height="32"></a></li>
        </ul>
      </div>
    </div>
  </div>
  <div class="footer-copyright grey lighten-2">
    <div class="container black-text">
    © 2016 Copyright Text
    <a class="black-text text-lighten-4 right" href="#!">More Links</a>
    </div>
  </div>
</footer>
<style type="text/css">
  .footer-img {
    display:inline;
    margin-left: 10px;
    } 
</style>


<!-- Compiled and minified JavaScript -->
<script type="text/javascript" src="scripts/jquery/dist/jquery.js"></script>
<script type="text/javascript" src="scripts/jquery/dist/jquery.min.js"></script>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
<script type="text/javascript" src="scripts/jquery-ui/jquery-ui.min.js"></script>
<script type="text/javascript" src="scripts/jquery-ui/jquery-ui.js"></script>
<script type="text/javascript" src="scripts/materialize/dist/js/materialize.min.js"></script>
<script type="text/javascript" src="scripts/materialize/dist/js/materialize.js"></script>





<script type="text/javascript" src="http://materializecss.com/templates/starter-template/js/init.js"></script>

